#
#	configuration variables for the example

## Main application file
MAIN = agmgen
DEPH = $(EXSNAPADV)/agm.h $(EXSNAPADV)/agmfit.h
DEPCPP = $(EXSNAPADV)/agm.cpp $(EXSNAPADV)/agmfit.cpp

