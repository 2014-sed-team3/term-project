#include "stdafx.h"
#include "mine.h"

void MineTralala(){printf("Tralala!\n");}

#include "dmine.cpp"
#include "tmine.cpp"
#include "wmine.cpp"

