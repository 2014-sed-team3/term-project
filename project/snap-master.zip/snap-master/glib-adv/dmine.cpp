#include "dmine.h"

void DMineTralala(){printf("Tralala!\n");}

#include "tbval.cpp"
#include "tb.cpp"
#include "dmhd.cpp"
#include "exset.cpp"
#include "dm.cpp"
#include "valds.cpp"
#include "valret.cpp"

#include "pest.cpp"
#include "aest.cpp"

