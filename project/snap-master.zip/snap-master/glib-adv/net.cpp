#include "stdafx.h"
#include "net.h"

void NetTralala(){printf("Tralala!\n");}

#include "sock.cpp"
#include "netobj.cpp"
#include "smtp.cpp"
#include "nntp.cpp"
#include "term.cpp"
#include "geoip.cpp"
#include "webbsfetch.cpp"
#include "webpgfetch.cpp"
#include "websrv.cpp"
#include "webnetobj.cpp"
#include "soap.cpp"
#include "appsrv.cpp"

